import { useRecoilState } from "recoil";
import { todoListAtom } from "../atoms/TodoListAtom";

function TodoList() {
  const [todo, setTodo] = useRecoilState(todoListAtom);
  return <div>TodoList</div>;
}

export default TodoList;
